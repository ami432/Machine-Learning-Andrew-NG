function g = sigmoid(z)
%SIGMOID Compute sigmoid function
%   g = SIGMOID(z) computes the sigmoid of z.

% You need to return the following variables correctly 
g = zeros(size(z));

% ====================== YOUR CODE HERE ======================
% Instructions: Compute the sigmoid of each value of z (z can be a matrix,
%               vector or scalar).

% compute the exponent value in the sigmoid function
exponent_term = exp(-1 * z);
% Compute the denominator term in the sigmoid function
denominator = 1 + exponent_term ;
% return the sigmoid value 
g = denominator .^ -1 ;

% =============================================================

end
